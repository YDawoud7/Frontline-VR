import { Component, Property } from '@wonderlandengine/api';
import { enable, disable } from './utils.js';

export class Options extends Component {
    static TypeName = 'options';

    static Properties = {
        infoText: Property.object(),
        outcome:  Property.object(),
    };

    start() {
        console.log('[Options] start() on object:', this.object.name);

        this.optionButtons = [];
        for (let i = 0; i < this.object.children.length; i++) {
            const child = this.object.children[i];
            if (child.getComponent('button')) {
                this.optionButtons.push(child);
                console.log('[Options] Found button child:', child.name);
            }
        }

        this.scenarioOptions = [
            [
                "Keep knife in place; apply firm pressure",
                () => {
                    console.log('[Options] GOOD choice callback');
                    const ctrl = this._getOutcomeController();
                    if (ctrl) ctrl.chooseGood();
                },
                [],
                4.0,
                "You follow the dispatcher’s instructions. Leaving the knife in place prevents massive bleeding. " +
                "You apply firm pressure around the wound and keep the victim calm until the ambulance arrives."
            ],
            [
                "Remove the knife; treat wound properly",
                () => {
                    console.log('[Options] BAD choice callback');
                    const ctrl = this._getOutcomeController();
                    if (ctrl) ctrl.chooseBad();
                },
                [],
                4.0,
                "As soon as you pull the knife out, the victim begins bleeding heavily. Without the object blocking the wound " +
                "there is massive internal and external bleeding. The victim loses consciousness and dies before help arrives. " +
                "In real life, removing an embedded object like this can be fatal – always leave it in place and apply pressure around it."
            ]
        ];

        this.setOptions(this.scenarioOptions);
    }

    _getOutcomeController() {
        if (!this.outcome) {
            console.warn('[Options] outcome property not assigned');
            return null;
        }
        const ctrl = this.outcome.getComponent('stab-outcome');
        if (!ctrl) {
            console.warn('[Options] outcome object has no stab-outcome component');
        }
        return ctrl;
    }

    setOptions(options, delay = 0) {
        const n = options.length;
        const nButtons = this.optionButtons.length;

        this.options = options;

        // Enable needed buttons
        for (let i = 0; i < n; i++) {
            enable(this.optionButtons[i]);
        }

        // Disable extra buttons
        for (let i = n; i < nButtons; i++) {
            const btn = this.optionButtons[i];
            setTimeout(() => disable(btn), delay * 1000 + 5);
        }

        // Set button labels
        for (let i = 0; i < n; i++) {
            const btn = this.optionButtons[i];

            let textComp = btn.getComponent('text');
            if (!textComp && btn.children.length > 0 && btn.children[0].children.length > 0) {
                const textObj = btn.children[0].children[0];
                textComp = textObj && textComp.getComponent('text');
            }

            if (textComp) {
                textComp.text = options[i][0];
                console.log('[Options] Set label for', btn.name, '→', options[i][0]);
            } else {
                console.warn('[Options] Could not find text component for button', btn.name);
            }
        }
    }

    optionClick(id) {
        if (!this.options || !this.options[id]) {
            console.warn('[Options] optionClick with invalid id:', id);
            return;
        }

        console.log('[Options] optionClick(', id, ')');

        const delay = this.options[id][3];
        const txt   = this.options[id][4];

        // Run scenario callback (this will call StabOutcome)
        this.options[id][1]();

        // Clear buttons immediately
        this.setOptions([], delay);
        disable(this.object);

        // After delay, show long explanation text
        setTimeout(() => {
            if (!this.infoText) return;
            const textComp = this.infoText.getComponent('text');
            if (textComp) {
                textComp.text = txt;
                console.log('[Options] Set outcome text after delay');
            } else {
                console.warn('[Options] infoText has no text component');
            }
        }, delay * 1000);
    }
}

