import { Component, Property } from '@wonderlandengine/api';
import { enable, disable } from './utils.js';

export class StabOutcome extends Component {
    static TypeName = 'stab-outcome';

    static Properties = {
        infoText:      Property.object(),

        attacker:      Property.object(),
        activeVictim:  Property.object(),
        idleVictim:    Property.object(),
        blood:         Property.object(),

        pressureHands: Property.object(),
        removeHands:   Property.object(),

        camera:        Property.object(),
        goodCameraPos: Property.object(),
        badCameraPos:  Property.object(),
    };

    start() {
        console.log('[StabOutcome] start() on object:', this.object.name);

        this._resolved = false;

        /* Initial visibility: everything about the final scene OFF */
        this._safeDisable(this.idleVictim, 'idleVictim');
        this._safeDisable(this.blood, 'blood');
        this._safeDisable(this.pressureHands, 'pressureHands');
        this._safeDisable(this.removeHands, 'removeHands');

        if (!this.attacker)      console.warn('[StabOutcome] attacker not assigned');
        if (!this.activeVictim)  console.warn('[StabOutcome] activeVictim not assigned');
        if (!this.camera)        console.warn('[StabOutcome] camera not assigned');
        if (!this.goodCameraPos) console.warn('[StabOutcome] goodCameraPos not assigned');
        if (!this.badCameraPos)  console.warn('[StabOutcome] badCameraPos not assigned');
    }

    _safeDisable(obj, name) {
        if (!obj) {
            console.warn('[StabOutcome] No object given for', name);
            return;
        }
        disable(obj);
        console.log('[StabOutcome] Disabled', name, '(', obj.name, ')');
    }

    _safeEnable(obj, name) {
        if (!obj) {
            console.warn('[StabOutcome] No object given for', name);
            return;
        }
        enable(obj);
        console.log('[StabOutcome] Enabled', name, '(', obj.name, ')');
    }

    _clearInfoText() {
        if (!this.infoText) return;
        const textComp = this.infoText.getComponent('text');
        if (textComp) {
            textComp.text = '';
            console.log('[StabOutcome] Cleared info text');
        } else {
            console.warn('[StabOutcome] infoText has no text component');
        }
    }

    _moveCameraTo(target, label) {
        if (!this.camera) {
            console.warn('[StabOutcome] camera not set, cannot move camera');
            return;
        }
        if (!target) {
            console.warn('[StabOutcome] target camera position for', label, 'is null');
            return;
        }

        const pos = new Float32Array(3);
        const rot = new Float32Array(4);

        target.getTranslationWorld(pos);
        target.getRotationWorld(rot);

        this.camera.setTranslationWorld(pos);
        this.camera.setRotationWorld(rot);

        console.log('[StabOutcome] Moved camera to', label, 'position from', target.name);
    }

    /* Shared work for both good and bad outcomes */
    _commonSetup(label) {
        if (this._resolved) {
            console.log('[StabOutcome]', label, 'called but outcome already resolved');
            return false;
        }
        this._resolved = true;

        console.log('[StabOutcome] Resolving outcome:', label);

        // Hide attacker & standing victim
        this._safeDisable(this.attacker, 'attacker');
        this._safeDisable(this.activeVictim, 'activeVictim');

        // Show idle body & blood
        this._safeEnable(this.idleVictim, 'idleVictim');
        this._safeEnable(this.blood, 'blood');

        // Clear text while the hands animation plays
        this._clearInfoText();

        return true;
    }

    chooseGood() {
        console.log('[StabOutcome] chooseGood() called');

        if (!this._commonSetup('GOOD')) return;

        // Camera close-up
        this._moveCameraTo(this.goodCameraPos || this.badCameraPos, 'GOOD');

        // Show and play "apply pressure" hands
        if (this.pressureHands) {
            this._safeEnable(this.pressureHands, 'pressureHands');
            const anim = this.pressureHands.getComponent('animation');
            if (anim) {
                console.log('[StabOutcome] Playing pressure hands animation');
                anim.play(0);
            } else {
                console.warn('[StabOutcome] pressureHands has no animation component');
            }
        } else {
            console.warn('[StabOutcome] pressureHands object not assigned');
        }

        // Text for the long explanation will be set later by options.js
    }

    chooseBad() {
        console.log('[StabOutcome] chooseBad() called');

        if (!this._commonSetup('BAD')) return;

        this._moveCameraTo(this.badCameraPos || this.goodCameraPos, 'BAD');

        if (this.removeHands) {
            this._safeEnable(this.removeHands, 'removeHands');
            const anim = this.removeHands.getComponent('animation');
            if (anim) {
                console.log('[StabOutcome] Playing remove-knife hands animation');
                anim.play(0);
            } else {
                console.warn('[StabOutcome] removeHands has no animation component');
            }
        } else {
            console.warn('[StabOutcome] removeHands object not assigned');
        }

        // Text for the long explanation will be set later by options.js
    }
}

